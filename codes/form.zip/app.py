from flask import Flask, request, render_template

app = Flask(__name__)

@app.route('/login')
def login():
    return render_template('form.html')

@app.route('/submit', methods=['POST'])
def submit():
    username = request.form.get('username')
    password = request.form.get('password')
    
    # Simple validation
    if username == "admin" and password == "12345":
        return f"Welcome, {username}!"
    else:
        return "Invalid credentials. Please try again."

if __name__ == '__main__':
    app.run(debug=True)
